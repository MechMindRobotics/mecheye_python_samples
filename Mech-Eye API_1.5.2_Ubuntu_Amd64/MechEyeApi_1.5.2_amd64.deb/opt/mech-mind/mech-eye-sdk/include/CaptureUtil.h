#pragma once
#include <iostream>
#include "MechEyeApi.h"
#include "OpenCVUtil.h"
#include "PclUtil.h"

inline void capture(mmind::api::MechEyeDevice& device, std::string suffix)
{
    const std::string colorFile = suffix.empty() ? "ColorMap.png" : "ColorMap_" + suffix + ".png ";
    const std::string depthFile = suffix.empty() ? "DepthMap.png" : "DepthMap_" + suffix + ".png ";
    const std::string pointCloudPath =
        suffix.empty() ? "PointCloud.ply" : "PointCloud_" + suffix + ".ply ";
    const std::string pointCloudColorPath =
        suffix.empty() ? "ColorPointCloud.ply" : "ColorPointCloud_" + suffix + ".ply ";

    mmind::api::ColorMap color;
    showError(device.captureColorMap(color));
    saveMap(color, colorFile);

    mmind::api::DepthMap depth;
    showError(device.captureDepthMap(depth));
    saveMap(depth, depthFile);

    mmind::api::PointXYZMap pointXYZMap;
    showError(device.capturePointXYZMap(pointXYZMap));
    savePLY(pointXYZMap, pointCloudPath);

    mmind::api::PointXYZBGRMap pointXYZBGRMap;
    showError(device.capturePointXYZBGRMap(pointXYZBGRMap));
    savePLY(pointXYZBGRMap, pointCloudColorPath);
}