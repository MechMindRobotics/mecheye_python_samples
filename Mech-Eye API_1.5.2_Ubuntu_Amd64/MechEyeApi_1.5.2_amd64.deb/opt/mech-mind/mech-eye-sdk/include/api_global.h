#pragma once

#ifndef DOXYGEN_DOCUMENTATION_BUILD

#ifdef _WIN32
#if defined(MMIND_API_LIBRARY)
#define MMIND_API_EXPORT __declspec(dllexport)
#else
#define MMIND_API_EXPORT __declspec(dllimport)
#endif
#else
#if defined(MMIND_API_LIBRARY)
#define MMIND_API_EXPORT __attribute((visibility("default")))
#else
#define MMIND_API_EXPORT __attribute((visibility("default")))
#endif
#endif

#endif
