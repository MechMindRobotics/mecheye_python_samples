#pragma once
#include <iostream>
#include <set>
#include <utility>
#include "MechEyeApi.h"

inline void showError(const mmind::api::ErrorStatus& status)
{
	if (status.isOK())
		return;
	std::cout << "Error Code : " << status.errorCode
		<< ", Error Description: " << status.errorDescription << std::endl;
}

inline void printDeviceInfo(const mmind::api::MechEyeDeviceInfo& deviceInfo)
{
	std::cout << "............................" << std::endl;
	std::cout << "Camera Model Name: " << deviceInfo.model << std::endl;
	std::cout << "Camera ID:         " << deviceInfo.id << std::endl;
	std::cout << "Camera IP Address: " << deviceInfo.ipAddress << std::endl;
	std::cout << "Hardware Version:  "
		<< "V" << deviceInfo.hardwareVersion << std::endl;
	std::cout << "Firmware Version:  "
		<< "V" << deviceInfo.firmwareVersion << std::endl;
	std::cout << "............................" << std::endl;
	std::cout << std::endl;
}

inline bool isNumber(const std::string& str)
{
	for (auto it = str.cbegin(); it != str.cend(); ++it) {
		if (*it < '0' || *it > '9')
			return false;
	}
	return true;
}

inline void printDeviceResolution(const mmind::api::DeviceResolution& deviceResolution)
{
	std::cout << "Color Map size : (width : " << deviceResolution.colorMapWidth
		<< ", height : " << deviceResolution.colorMapHeight << ")." << std::endl;
	std::cout << "Depth Map size : (width : " << deviceResolution.depthMapWidth
		<< ", height : " << deviceResolution.depthMapHeight << ")." << std::endl;
}

inline void printMatrix(const std::string& name, const double* cameraMatrix)
{
	std::cout << name << ": " << std::endl
		<< "    [" << cameraMatrix[0] << ", " << 0 << ", " << cameraMatrix[2] << "]"

		<< std::endl
		<< "    [" << 0 << ", " << cameraMatrix[1] << ", " << cameraMatrix[3] << "]"

		<< std::endl
		<< "    [" << 0 << ", " << 0 << ", " << 1 << "]" << std::endl;
	std::cout << std::endl;
}

inline void printDistCoeffs(const std::string& name, const double* distCoeffs)
{
	std::cout << name << ": " << std::endl
		<< "    k1: " << distCoeffs[0] << ", k2: " << distCoeffs[1]
		<< ", p1: " << distCoeffs[2] << ", p2: " << distCoeffs[3] << ", k3: " << distCoeffs[4]
		<< std::endl;
	std::cout << std::endl;
}

inline void printCalibParams(const mmind::api::DeviceIntri& deviceIntri)
{
	printMatrix("CameraMatrix", deviceIntri.cameraMatrix);
	printDistCoeffs("CameraDistCoeffs", deviceIntri.distCoeffs);
}

inline bool findAndConnect(mmind::api::MechEyeDevice& device)
{
	std::cout << "Find Mech-Eye device..." << std::endl;
	std::vector<mmind::api::MechEyeDeviceInfo> deviceInfoList =
		mmind::api::MechEyeDevice::enumerateMechEyeDeviceList();

	if (deviceInfoList.empty()) {
		std::cout << "No Mech-Eye device found." << std::endl;
		return false;
	}

	for (int i = 0; i < deviceInfoList.size(); i++) {
		std::cout << "Mech-Eye device index : " << i << std::endl;
		printDeviceInfo(deviceInfoList[i]);
	}

	std::cout << "Please enter the device index you want to connect: ";
	unsigned inputIndex;

	while (1) {
		std::string str;
		std::cin >> str;
		if (isNumber(str) && atoi(str.c_str()) < deviceInfoList.size()) {
			inputIndex = atoi(str.c_str());
			break;
		}
		std::cout << "Input invalid! Please enter the device index you want to connect: ";
	}

	mmind::api::ErrorStatus status;
	status = device.connect(deviceInfoList[inputIndex]);

	if (!status.isOK()) {
		showError(status);
		return false;
	}

	std::cout << "Connect Mech-Eye Success." << std::endl;
	return true;
}

inline std::pair<mmind::api::MechEyeDevice*, int> findAndConnectMulti()
{
	std::cout << "Find Mech-Eye device..." << std::endl;
	std::vector<mmind::api::MechEyeDeviceInfo> deviceInfoList =
		mmind::api::MechEyeDevice::enumerateMechEyeDeviceList();

	if (deviceInfoList.empty()) {
		std::cout << "No Mech-Eye device found." << std::endl;
		return std::make_pair(nullptr, 0);
	}

	for (int i = 0; i < deviceInfoList.size(); i++) {
		std::cout << "Mech-Eye device index : " << i << std::endl;
		printDeviceInfo(deviceInfoList[i]);
	}

	std::string str;
	std::set<unsigned> indices;

	while (1) {
		std::cout << "Please enter the device index you want to connect: " << std::endl;
		std::cout << "Enter a c to terminate adding devices" << std::endl;

		std::cin >> str;
		if (str == "c")
			break;
		if (isNumber(str) && atoi(str.c_str()) < deviceInfoList.size())
			indices.emplace(atoi(str.c_str()));
		else
			std::cout << "Input invalid! Please enter the device index you want to connect: ";
	}

	mmind::api::MechEyeDevice* devices = new mmind::api::MechEyeDevice[indices.size()];

	std::set<unsigned>::iterator it = indices.begin();
	for (int i = 0; i < indices.size() && it != indices.end(); ++i, ++it) {
		showError(devices[i].connect(deviceInfoList[*it]));
	}

	return std::make_pair(devices, indices.size());
}