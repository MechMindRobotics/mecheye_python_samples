#pragma once
#include <memory>
#include <vector>
#include "api_global.h"
#include "MechEyeFrame.hpp"
#include "MechEyeDataType.h"
#include "MechEyeSettings.h"

namespace mmind {

namespace api {

class MechEyeDeviceImpl;
/**
 * @brief Interface that is used to connect the Mech-Eye device and access basic information of the
 * device.
 */
class MMIND_API_EXPORT MechEyeDevice
{
public:
    /**
     * Constructor.
     */
    MechEyeDevice();

    /**
     * Destructor.
     */
    ~MechEyeDevice();

    /**
     * No copy.
     */
    MechEyeDevice(const MechEyeDevice&) = delete;

    /**
     * No copy.
     */
    MechEyeDevice& operator=(const MechEyeDevice&) = delete;

    /**
     * @brief Enumerates Mech-Eye devices by the type of @ref MechEyeDeviceInfo identifying the
     * device.
     * @return
     *  Information on all detectable Mech-Eye devices.
     */
    static std::vector<MechEyeDeviceInfo> enumerateMechEyeDeviceList();

    /**
     * @brief Connects to the device by the @ref MechEyeDeviceInfo identifying a device.
     * @param [in] info  he device information used to connect the device which can be
     * obtained by @ref enumerateMechEyeDeviceList function.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus connect(const MechEyeDeviceInfo& info);

    /**
     * @brief Disconnects from the device.
     */
    void disconnect();

    /**
     * @brief Gets the basic information about the connected device.
     * @param [out] info See @ref MechEyeDeviceInfo for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getDeviceInfo(MechEyeDeviceInfo& info) const;

    /**
     * @brief Gets the intrinsic camera parameter about the connected device.
     * @param [out] intri See @ref DeviceIntri for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getDeviceIntri(DeviceIntri& intri) const;

    /**
     * @brief Gets the device resolution.
     * @param [out] imageResolution See @ref DeviceResolution for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getDeviceResolution(DeviceResolution& imageResolution) const;

    /**
     * @brief Captures a color image.
     * @param [out] colorMap See @ref Frame for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus captureColorMap(ColorMap& colorMap) const;

    /**
     * @brief Captures a depth image.
     * @param [out] depthMap See @ref Frame for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus captureDepthMap(DepthMap& depthMap) const;

    /**
     * @brief Captures a point cloud image.
     * @param [out] pointXYZMap See @ref Frame for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus capturePointXYZMap(PointXYZMap& pointXYZMap) const;

    /**
     * @brief Captures a colored point cloud image.
     * @param [out] pointXYZBGRMap See @ref Frame for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus capturePointXYZBGRMap(PointXYZBGRMap& pointXYZBGRMap) const;

    /**
     * @brief Sets the camera exposure mode to capture the 2D images.
     * @param [in] value See \ref Scanning2DSettings.ExposureMode for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan2DExposureMode(Scanning2DSettings::Scan2DExposureMode value) const;

    /**
     * @brief Gets the camera exposure mode to capture the 2D images.
     * @param [out] value See \ref Scanning2DSettings.ExposureMode for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan2DExposureMode(Scanning2DSettings::Scan2DExposureMode& value) const;

    /**
     * @brief Sets the camera exposure time in \ref Scanning2DSettings.Timed exposure mode.
     * @param [in] value See \ref Scanning2DSettings.ExposureTime for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan2DExposureTime(double value) const;

    /**
     * @brief  Gets the camera exposure time in \ref Scanning2DSettings.Timed exposure mode.
     * @param [out] value See \ref Scanning2DSettings.ExposureTime for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan2DExposureTime(double& value) const;

    /**
     * @brief Sets the camera HDR exposure sequence in \ref Scanning2DSettings.HDR exposure mode.
     * @param [in] values See \ref Scanning2DSettings.HDRExposureSequence for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan2DHDRExposureSequence(std::vector<double>& values) const;

    /**
     * @brief  Gets the camera HDR exposure sequence in \ref Scanning2DSettings.HDR exposure mode.
     * @param [out] values See \ref Scanning2DSettings.HDRExposureSequence for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan2DHDRExposureSequence(std::vector<double>& values) const;

    /**
     * @brief Sets the expected gray value in \ref Scanning2DSettings.Auto exposure mode.
     * @param [in] value See \ref Scanning2DSettings.ExpectedGrayValue for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan2DExpectedGrayValue(int value) const;

    /**
     * @brief Gets the expected gray value in \ref Scanning2DSettings.Auto exposure mode.
     * @param [out] valus See \ref Scanning2DSettings.ExpectedGrayValue for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan2DExpectedGrayValue(int& value) const;

    /**
     * @brief Sets whether gray level transformation algorithm is used or not.
     * @param [in] value See \ref Scanning2DSettings.ToneMappingEnable for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan2DToneMappingEnable(bool value) const;

    /**
     * @brief  Gets whether gray level transformation algorithm is used or not.
     * @param [out] value See \ref Scanning2DSettings.ToneMappingEnable for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan2DToneMappingEnable(bool& value) const;

    /**
     * @brief Sets the image sharpen factor.
     * @param [in] value See \ref Scanning2DSettings.SharpenFactor for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan2DSharpenFactor(double value) const;

    /**
     * @brief  Gets the image sharpen factor.
     * @param [out] value See \ref Scanning2DSettings.SharpenFactor for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan2DSharpenFactor(double& value) const;

    /**
     * @brief Sets ROI to capture the 2D image.
     * @param [in] value See @ref Scanning2DSettings.Scan2DROI for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan2DROI(const ROI& value) const;

    /**
     * @brief Gets ROI to capture the 2D image.
     * @param [out] value See @ref Scanning2DSettings.Scan2DROI for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan2DROI(ROI& value) const;

    /**
     * @brief Sets the exposure time of the camera to capture the 3D image.
     * @param [in] valueSequence See @ref Scanning3DSettings.ExposureSequence for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan3DExposure(const std::vector<double>& valueSequence) const;

    /**
     * @brief Gets the exposure time sequence of the camera to capture the 3D image.
     * @param [out] valueSequence See @ref Scanning3DSettings.ExposureSequence for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan3DExposure(std::vector<double>& valueSequence) const;

    /**
     * @brief Sets gain to capture the 3d image.
     * @param [in] value  See @ref Scanning3DSettings.Gain for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan3DGain(double value) const;

    /**
     * @brief Gets gain to capture the 3d image.
     * @param [out] value See @ref Scanning3DSettings.Gain for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan3DGain(double& value) const;

    /**
     * @brief Sets ROI to capture the 3D image.
     * @param [in] value See @ref Scanning3DSettings.Scan3DROI for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setScan3DROI(const ROI& value) const;

    /**
     * @brief Gets ROI to capture the 3D image.
     * @param [out] value See @ref Scanning3DSettings.Scan3DROI for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getScan3DROI(ROI& value) const;

    /**
     * @brief Sets depth range in 3D image.
     * @param [in] value See @ref Scanning3DSettings.DepthRange for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setDepthRange(const DepthRange& value) const;

    /**
     * @brief Gets depth range in 3D image.
     * @param [out] value See @ref Scanning3DSettings.DepthRange for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getDepthRange(DepthRange& value) const;

    /**
     * @brief Sets the signal contrast threshold for effective pixels.
     * @param [in] value See @ref PointCloudProcessingSettings.FringeContrastThreshold for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setFringeContrastThreshold(int value) const;

    /**
     * @brief Gets the signal contrast threshold for effective pixels.
     * @param [out] value See @ref PointCloudProcessingSettings.FringeContrastThreshold for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getFringeContrastThreshold(int& value) const;

    /**
     * @brief Sets the signal minimum threshold for effective pixels.
     * @param [in] value See @ref PointCloudProcessingSettings.FringeMinThreshold for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setFringeMinThreshold(int value) const;

    /**
     * @brief Gets the signal minimum threshold for effective pixels.
     * @param [out] value See @ref PointCloudProcessingSettings.FringeMinThreshold for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getFringeMinThreshold(int& value) const;

    /**
     * @brief Sets the point cloud outliers removal algorithm.
     * @param [in] value See @ref PointCloudProcessingSettings.OutlierFilterMode for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setCloudOutlierFilterMode(
        PointCloudProcessingSettings::CloudOutlierFilterMode value) const;

    /**
     * @brief Gets the point cloud outliers removal algorithm.
     * @param [out] value See @ref PointCloudProcessingSettings.OutlierFilterMode for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getCloudOutlierFilterMode(
        PointCloudProcessingSettings::CloudOutlierFilterMode& value) const;

    /**
     * @brief Sets the point cloud smoothing algorithm.
     * @param [in] value See @ref PointCloudProcessingSettings.SmoothMode for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setCloudSmoothMode(PointCloudProcessingSettings::CloudSmoothMode value) const;

    /**
     * @brief Gets the point cloud smoothing algorithm.
     * @param [out] value See @ref PointCloudProcessingSettings.SmoothMode for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getCloudSmoothMode(PointCloudProcessingSettings::CloudSmoothMode& value) const;

    /**
     * @brief Sets laser device settings. Only support with Mech-Eye Laser series industrial 3D
     * camera.
     * @param [in] value See @ref LaserSettings for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus setLaserSettings(LaserSettings value) const;

    /**
     * @brief Gets laser device settings. Only support with Mech-Eye Laser series industrial 3D
     * camera.
     * @param [out] value See @ref LaserSettings for details.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus getLaserSettings(LaserSettings& value) const;

    /**
     * @brief Saves all parameters to the current user set.
     * @return See @ref ErrorStatus for details.
     */
    ErrorStatus saveAllSettingsToUserSets() const;

    /**
     * Sets the current user set by user set name. \n
     * @details Call @ref saveAllSettingsToUserSets to take effect permanently on the device.
     * @param [in] userSetName
     * @return See @ref ErrorStatus for details.
     * @see saveAllSettingsToUserSets
     */
    ErrorStatus setCurrentUserSet(const std::string& userSetName) const;

    /**
     * @brief Gets the name of the current user set.
     * @param [out] userSetName
     * @return See @ref ErrorStatus for details.
     * @see getAllUserSets
     */
    ErrorStatus getCurrentUserSet(std::string& userSetName) const;

    /**
     * @brief Gets the names of all user sets.
     * @param [out] userSetNames
     * @return See @ref ErrorStatus for details.
     * @see getCurrentUserSet
     */
    ErrorStatus getAllUserSets(std::vector<std::string>& userSetNames) const;

    /**
     * Deletes the user set by the user set name. If input name is the current user set it will
     * change the current user set to the previous index value in the user set list.
     * @details Call @ref saveAllSettingsToUserSets to take effect permanently on the device.
     * @param [in] userSetName
     * @return See @ref ErrorStatus for details.
     * @see saveAllSettingsToUserSets
     */
    ErrorStatus deleteUserSet(const std::string& userSetName) const;

    /**
     * Adds a new user set by the user set name and sets all the current device settings to it. It
     * will also change the current user set to the input value if adds success. \n
     * @details Call @ref saveAllSettingsToUserSets to take effect permanently on the device. \n
     * @param [in] userSetName
     * @return See @ref ErrorStatus for details.
     * @see saveAllSettingsToUserSets
     */
    ErrorStatus addUserSet(const std::string& userSetName) const;

private:
    std::unique_ptr<MechEyeDeviceImpl> _d;
};

} // namespace api
} // namespace mmind
