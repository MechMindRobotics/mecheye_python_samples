#pragma once
#include <iostream>
#include <opencv2/imgcodecs.hpp>
#include "MechEyeApi.h"

inline void saveMap(mmind::api::ColorMap color, std::string path)
{
    cv::Mat color8UC3 = cv::Mat(color.height(), color.width(), CV_8UC3, color.data());
    cv::imwrite(path, color8UC3);
    std::cout << "Capture and save color image : " << path << std::endl;
}

inline void saveMap(mmind::api::DepthMap depth, std::string path)
{
    cv::Mat depth32F = cv::Mat(depth.height(), depth.width(), CV_32FC1, depth.data());
    cv::imwrite(path, depth32F);
    std::cout << "Capture and save depth image : " << path << std::endl;
}
